# Changelog for haskell-new

## Unreleased changes
