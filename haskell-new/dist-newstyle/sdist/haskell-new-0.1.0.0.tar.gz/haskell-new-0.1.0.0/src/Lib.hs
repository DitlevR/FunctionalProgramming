import qualified Data.ByteString.Lazy as B

module Lib ( jsonFile
    ) where



 jsonFile :: FilePath
 jsonFile = "data.json"

 getJSON :: IO B.ByteString
 getJSON = B.readFile jsonFile

